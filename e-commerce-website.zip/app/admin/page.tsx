"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  LayoutDashboard,
  FileText,
  Users,
  ShoppingCart,
  DollarSign,
  TrendingUp,
  MoreVertical,
  Search,
  Download,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
} from "lucide-react"

export default function AdminDashboard() {
  const [searchQuery, setSearchQuery] = useState("")

  const stats = [
    {
      title: "Total Revenue",
      value: "$45,231.89",
      change: "+20.1%",
      trend: "up",
      icon: DollarSign,
    },
    {
      title: "Active Notes",
      value: "10,452",
      change: "+12.5%",
      trend: "up",
      icon: FileText,
    },
    {
      title: "Total Users",
      value: "52,183",
      change: "+8.2%",
      trend: "up",
      icon: Users,
    },
    {
      title: "Orders Today",
      value: "234",
      change: "+19%",
      trend: "up",
      icon: ShoppingCart,
    },
  ]

  const recentNotes = [
    {
      id: 1,
      title: "Advanced Calculus III - Complete Lecture Notes",
      seller: "John Smith",
      subject: "Mathematics",
      price: 29.99,
      sales: 127,
      status: "approved",
      uploadDate: "2024-12-15",
    },
    {
      id: 2,
      title: "Data Structures & Algorithms - Full Semester",
      seller: "Sarah Johnson",
      subject: "Computer Science",
      price: 34.99,
      sales: 203,
      status: "approved",
      uploadDate: "2024-12-14",
    },
    {
      id: 3,
      title: "Organic Chemistry Lab Reports & Theory",
      seller: "Mike Davis",
      subject: "Sciences",
      price: 24.99,
      sales: 98,
      status: "pending",
      uploadDate: "2024-12-16",
    },
    {
      id: 4,
      title: "Corporate Finance - Case Studies",
      seller: "Emily Chen",
      subject: "Business",
      price: 39.99,
      sales: 156,
      status: "approved",
      uploadDate: "2024-12-13",
    },
    {
      id: 5,
      title: "Machine Learning Foundations",
      seller: "Alex Kumar",
      subject: "Computer Science",
      price: 44.99,
      sales: 189,
      status: "pending",
      uploadDate: "2024-12-16",
    },
  ]

  const recentOrders = [
    {
      id: "ORD-001234",
      customer: "David Wilson",
      note: "Advanced Calculus III",
      amount: 29.99,
      status: "completed",
      date: "2024-12-16 10:30",
    },
    {
      id: "ORD-001235",
      customer: "Lisa Anderson",
      note: "Data Structures & Algorithms",
      amount: 34.99,
      status: "completed",
      date: "2024-12-16 10:15",
    },
    {
      id: "ORD-001236",
      customer: "James Brown",
      note: "Organic Chemistry",
      amount: 24.99,
      status: "processing",
      date: "2024-12-16 09:45",
    },
    {
      id: "ORD-001237",
      customer: "Maria Garcia",
      note: "Corporate Finance",
      amount: 39.99,
      status: "completed",
      date: "2024-12-16 09:20",
    },
    {
      id: "ORD-001238",
      customer: "Tom Martinez",
      note: "Machine Learning Foundations",
      amount: 44.99,
      status: "failed",
      date: "2024-12-16 08:55",
    },
  ]

  const topSellers = [
    {
      id: 1,
      name: "Sarah Johnson",
      email: "sarah.j@university.edu",
      totalSales: "$12,450",
      notesCount: 18,
      rating: 4.9,
    },
    {
      id: 2,
      name: "John Smith",
      email: "john.smith@university.edu",
      totalSales: "$9,890",
      notesCount: 15,
      rating: 4.8,
    },
    {
      id: 3,
      name: "Emily Chen",
      email: "emily.c@university.edu",
      totalSales: "$8,720",
      notesCount: 12,
      rating: 4.9,
    },
    {
      id: 4,
      name: "Alex Kumar",
      email: "alex.k@university.edu",
      totalSales: "$7,560",
      notesCount: 10,
      rating: 5.0,
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <Badge className="bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20">
            <CheckCircle className="h-3 w-3 mr-1" />
            Approved
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20">
            <Clock className="h-3 w-3 mr-1" />
            Pending
          </Badge>
        )
      case "rejected":
        return (
          <Badge className="bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20">
            <XCircle className="h-3 w-3 mr-1" />
            Rejected
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getOrderStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20">Completed</Badge>
        )
      case "processing":
        return <Badge className="bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20">Processing</Badge>
      case "failed":
        return <Badge className="bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20">Failed</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <LayoutDashboard className="h-7 w-7 text-primary" />
              <div>
                <h1 className="text-xl font-semibold">Admin Dashboard</h1>
                <p className="text-xs text-muted-foreground">NoteMarket Administration</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </Button>
              <Button variant="default" size="sm">
                View Site
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <Card key={stat.title}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                    <TrendingUp className="h-3 w-3 text-green-600" />
                    <span className="text-green-600">{stat.change}</span>
                    <span>from last month</span>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="notes" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="notes">Notes</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="sellers">Sellers</TabsTrigger>
          </TabsList>

          {/* Notes Tab */}
          <TabsContent value="notes" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Note Management</CardTitle>
                    <CardDescription>Review and manage uploaded study notes</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search notes..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9 w-64"
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Note Title</TableHead>
                      <TableHead>Seller</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Sales</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentNotes.map((note) => (
                      <TableRow key={note.id}>
                        <TableCell className="font-medium max-w-xs">
                          <div className="truncate">{note.title}</div>
                        </TableCell>
                        <TableCell>{note.seller}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{note.subject}</Badge>
                        </TableCell>
                        <TableCell>${note.price}</TableCell>
                        <TableCell>{note.sales}</TableCell>
                        <TableCell>{getStatusBadge(note.status)}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{note.uploadDate}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <CheckCircle className="h-4 w-4 mr-2" />
                                Approve
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-destructive">
                                <XCircle className="h-4 w-4 mr-2" />
                                Reject
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Order Management</CardTitle>
                    <CardDescription>Track and manage customer orders</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm">
                      Filter
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Note</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-mono text-sm">{order.id}</TableCell>
                        <TableCell className="font-medium">{order.customer}</TableCell>
                        <TableCell>{order.note}</TableCell>
                        <TableCell className="font-semibold">${order.amount}</TableCell>
                        <TableCell>{getOrderStatusBadge(order.status)}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{order.date}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Order
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Download Invoice
                              </DropdownMenuItem>
                              {order.status === "failed" && (
                                <DropdownMenuItem>
                                  <AlertCircle className="h-4 w-4 mr-2" />
                                  Retry Payment
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sellers Tab */}
          <TabsContent value="sellers" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Top Sellers</CardTitle>
                    <CardDescription>Manage and monitor seller performance</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Seller Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Total Sales</TableHead>
                      <TableHead>Notes</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topSellers.map((seller) => (
                      <TableRow key={seller.id}>
                        <TableCell className="font-medium">{seller.name}</TableCell>
                        <TableCell className="text-muted-foreground">{seller.email}</TableCell>
                        <TableCell className="font-semibold">{seller.totalSales}</TableCell>
                        <TableCell>{seller.notesCount} notes</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <span className="font-semibold">{seller.rating}</span>
                            <span className="text-yellow-500">★</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Profile
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <FileText className="h-4 w-4 mr-2" />
                                View Notes
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Download className="h-4 w-4 mr-2" />
                                Export Data
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
