"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, ShoppingCart, BookOpen, GraduationCap, FileText, Star, Menu, X } from "lucide-react"
import Link from "next/link"

export default function NotesMarketplace() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [cartCount, setCartCount] = useState(0)

  const categories = [
    { name: "Mathematics", icon: "∑", count: 245 },
    { name: "Computer Science", icon: "</>", count: 189 },
    { name: "Business", icon: "₿", count: 156 },
    { name: "Sciences", icon: "⚛", count: 298 },
    { name: "Engineering", icon: "⚙", count: 178 },
    { name: "Liberal Arts", icon: "✎", count: 134 },
  ]

  const featuredNotes = [
    {
      id: 1,
      title: "Advanced Calculus III - Complete Lecture Notes",
      subject: "Mathematics",
      university: "MIT",
      rating: 4.9,
      reviews: 127,
      price: 29.99,
      pages: 156,
      bestseller: true,
    },
    {
      id: 2,
      title: "Data Structures & Algorithms - Full Semester",
      subject: "Computer Science",
      university: "Stanford",
      rating: 4.8,
      reviews: 203,
      price: 34.99,
      pages: 189,
      bestseller: true,
    },
    {
      id: 3,
      title: "Organic Chemistry Lab Reports & Theory",
      subject: "Sciences",
      university: "Berkeley",
      rating: 4.7,
      reviews: 98,
      price: 24.99,
      pages: 142,
      bestseller: false,
    },
    {
      id: 4,
      title: "Corporate Finance - Case Studies & Notes",
      subject: "Business",
      university: "Harvard",
      rating: 4.9,
      reviews: 156,
      price: 39.99,
      pages: 234,
      bestseller: false,
    },
    {
      id: 5,
      title: "Machine Learning Foundations",
      subject: "Computer Science",
      university: "CMU",
      rating: 5.0,
      reviews: 189,
      price: 44.99,
      pages: 278,
      bestseller: true,
    },
    {
      id: 6,
      title: "Constitutional Law - Complete Notes",
      subject: "Liberal Arts",
      university: "Yale",
      rating: 4.8,
      reviews: 76,
      price: 32.99,
      pages: 198,
      bestseller: false,
    },
  ]

  const handleAddToCart = () => {
    setCartCount((prev) => prev + 1)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <GraduationCap className="h-8 w-8 text-primary" />
              <span className="text-2xl font-semibold tracking-tight">NoteMarket</span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                Browse
              </a>
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                Categories
              </a>
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                Sell Notes
              </a>
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                How It Works
              </a>
            </nav>

            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Button>
              <Link href="/auth/sign-in">
                <Button variant="default" className="hidden md:inline-flex">
                  Sign In
                </Button>
              </Link>
              <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <nav className="md:hidden pt-4 pb-2 flex flex-col gap-3 border-t border-border mt-4">
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                Browse
              </a>
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                Categories
              </a>
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                Sell Notes
              </a>
              <a href="#" className="text-sm font-medium hover:text-primary transition-colors">
                How It Works
              </a>
              <Link href="/auth/sign-in">
                <Button variant="default" className="w-full mt-2">
                  Sign In
                </Button>
              </Link>
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="border-b border-border bg-muted/30">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-balance mb-6">
              Premium study notes from top students
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground text-pretty mb-8 leading-relaxed">
              Access high-quality lecture notes, study guides, and exam prep materials from the world's best
              universities. Ace your courses with proven resources.
            </p>

            {/* Search Bar */}
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for notes by course, subject, or university..."
                className="pl-12 pr-4 py-6 text-base rounded-xl"
              />
            </div>

            <div className="flex flex-wrap justify-center gap-3 mt-6">
              <Badge variant="secondary" className="px-4 py-1.5">
                Calculus
              </Badge>
              <Badge variant="secondary" className="px-4 py-1.5">
                Physics
              </Badge>
              <Badge variant="secondary" className="px-4 py-1.5">
                Algorithms
              </Badge>
              <Badge variant="secondary" className="px-4 py-1.5">
                Chemistry
              </Badge>
              <Badge variant="secondary" className="px-4 py-1.5">
                Finance
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="border-b border-border">
        <div className="container mx-auto px-4 py-16">
          <h2 className="text-3xl font-bold mb-8">Browse by subject</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Card key={category.name} className="hover:shadow-lg transition-shadow cursor-pointer group">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">{category.icon}</div>
                  <h3 className="font-semibold mb-1 text-sm">{category.name}</h3>
                  <p className="text-xs text-muted-foreground">{category.count} notes</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Notes Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2">Top-rated notes</h2>
            <p className="text-muted-foreground">Handpicked by students, verified by educators</p>
          </div>
          <Button variant="outline">View All</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredNotes.map((note) => (
            <Card key={note.id} className="group hover:shadow-xl transition-all">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="outline" className="text-xs">
                    {note.subject}
                  </Badge>
                  {note.bestseller && <Badge className="bg-accent text-accent-foreground">Bestseller</Badge>}
                </div>
                <h3 className="font-semibold text-lg leading-tight group-hover:text-primary transition-colors text-balance">
                  {note.title}
                </h3>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                  <BookOpen className="h-4 w-4" />
                  <span>{note.university}</span>
                  <span className="text-xs">•</span>
                  <span>{note.pages} pages</span>
                </div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-primary text-primary" />
                    <span className="font-semibold text-sm">{note.rating}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">({note.reviews} reviews)</span>
                </div>
              </CardContent>
              <CardFooter className="flex items-center justify-between pt-3 border-t">
                <div className="flex items-baseline gap-1">
                  <span className="text-2xl font-bold">${note.price}</span>
                </div>
                <Button size="sm" onClick={handleAddToCart}>
                  Add to Cart
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold mb-2">10,000+</div>
              <div className="text-lg opacity-90">Quality Notes</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">50,000+</div>
              <div className="text-lg opacity-90">Happy Students</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">200+</div>
              <div className="text-lg opacity-90">Universities</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="container mx-auto px-4 py-16 border-b border-border">
        <h2 className="text-3xl font-bold text-center mb-12">How it works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 max-w-5xl mx-auto">
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-semibold text-xl mb-3">1. Browse & Search</h3>
            <p className="text-muted-foreground leading-relaxed">
              Find notes from your course using our powerful search and filtering system
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingCart className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-semibold text-xl mb-3">2. Purchase</h3>
            <p className="text-muted-foreground leading-relaxed">
              Secure checkout with instant digital delivery to your email
            </p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="h-8 w-8 text-primary" />
            </div>
            <h3 className="font-semibold text-xl mb-3">3. Study & Succeed</h3>
            <p className="text-muted-foreground leading-relaxed">
              Download high-quality PDFs and ace your exams with confidence
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-muted/30 border-b border-border">
        <div className="container mx-auto px-4 py-16 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Have great notes? Start earning today</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            Share your knowledge and earn passive income. Join thousands of top students already monetizing their study
            materials.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="default">
              Start Selling
            </Button>
            <Button size="lg" variant="outline">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <GraduationCap className="h-6 w-6 text-primary" />
                <span className="text-xl font-semibold">NoteMarket</span>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                The trusted marketplace for premium study materials from top universities worldwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Marketplace</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Browse Notes
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Categories
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Top Sellers
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    New Arrivals
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sellers</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Start Selling
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Seller Guidelines
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Pricing
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Resources
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    About Us
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-foreground transition-colors">
                    Terms of Service
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 NoteMarket. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
